import pymongo
from mysql import mysql
from sklearn.tree import DecisionTreeRegressor
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def process_area(house):
    '''
    处理area字段得到几室几厅几卫
    '''
    room = str(house.split('室')[0])
    if '厅' in house:
        hall = str(house.split('厅')[0][-1])
    else:
        hall = '0'
    if '卫' in house:
        toilet = str(house.split('卫')[0][-1])
    else:
        toilet = '0'

    return [room, hall, toilet]


def get_data():
    '''
    连接mongodb获取所有的数据保存至data.csv
    '''
    conn = db['One']
    cursor = conn['rent']

    fp = open('data.csv', 'w', encoding='utf-8')
    col_name = ['id', 'room', 'hall', 'toilet', 'house_area', 'rent_money']
    fp.write(','.join(col_name) + '\n')

    urls = []
    i = 0
    #不要租金值为面议的文档并去除‘url_now’重复的文档
    for item in cursor.find({'rent': {'$ne': '面议'}}):
        if float(item['area'].split('\xa0\xa0')[1][:-1]) > 200:
            continue

        if float(item['rent']) < 200 or float(item['rent']) > 5000:
            continue

        if item['url_now'] in urls:
            continue
        urls.append(item['url_now'])

        line = [str(i)]
        room_hall_toilet = process_area(item['area'].split('\xa0\xa0')[0])
        line.extend(room_hall_toilet)
        line.append(item['area'].split('\xa0\xa0')[1][:-1])
        line.append(item['rent'])
        fp.write(','.join(line) + '\n')
        i += 1

    fp.close()


def model(X_train, y_train, X_test, **kwargs):
    #
    # if len(X_test.shape) == 1:
    #     X_test = np.array(X_test).reshape(-1, 1)
    #
    # if len(X_train.shape) == 1:
    #     X_train = np.array(X_train).reshape(-1, 1)

    # poly_reg = PolynomialFeatures(degree=5)
    # X_train = poly_reg.fit_transform(X_train)
    # X_test = poly_reg.fit_transform(X_test)
    # clf = DecisionTreeRegressor(**kwargs)

    clf = LinearRegression(**kwargs)

    clf.fit(X_train, y_train)
    return clf.predict(X_test)


def is_outliers(y_true, y_pred):
    '''
    对单条数据进行异常值检测
    '''
    if (y_true - y_pred) / y_true > 0.6:
        return True
    elif (y_true - y_pred) / y_true < -3:
        return True
    else:
        return False


def new_conn(**kwargs):
    db = mysql(**kwargs)

    return db


def to_mysql(conn, table, data_dict):
    '''
    将单条的数据插入mysql对应表中
    '''
    conn.insert(table, data_dict)


def metrics(y_true, y_pred):
    print('rmse: ', np.sqrt(mean_squared_error(y_true, y_pred)))
    print('mae: ', mean_absolute_error(y_true, y_pred))
    print('r2: ', r2_score(y_true, y_pred))


def run(X, y, conn=None, plot=False, insert=False, table=None, clean_table=True):
    if len(y.shape) == 1:
        y = y.reshape(-1, 1)
    if len(X.shape) == 1:
        X = X.reshape(-1, 1)
    pred_tmp = model(X, y, X)

    index = 0
    outliers_index = []
    for y_true, y_pred in zip(y, pred_tmp):
        if is_outliers(y_true[0], y_pred):
            outliers_index.append(index)
        index += 1

    new_X, new_y = X[list(set(range(len(X))) - set(outliers_index)), :],\
                   y[list(set(range(len(X))) - set(outliers_index)), :]
    # pred = model(new_X, new_y, new_X)

    metrics(y, pred_tmp)
    if plot:
        plt.scatter(new_X, new_y, color='g')
        plt.scatter(X[outliers_index, :], y[outliers_index, :], color='r')
        # X = [x[0] for x in sorted(zip(X, pred_tmp))]
        # pred_tmp = [x[1] for x in sorted(zip(X, pred_tmp))]
        plt.plot(X, pred_tmp, color='y', linewidth=3)
        plt.show()

    if insert:
        if clean_table:
            conn.clean_table(table)
        for i in range(len(X)):
            data_dict = {'room': X[i][0], 'hall': X[i][1], 'toilet': X[i][2],
                         'area': X[i][3], 'money': y[i][0]}
            if i in outliers_index:
                print(i)
                data_dict['outliers'] = 1
            else:
                data_dict['outliers'] = 0
            data_dict['pred_money'] = pred_tmp[i][0]
            to_mysql(conn, table, data_dict)

    return pred_tmp


def model_house_type(data):
    '''
    单独对房子户型进行建模，特征值为 'room', 'hall', 'toilet'
    '''

    X = data[['room', 'hall', 'toilet']].values
    y = data['rent_money'].values
    pred = run(X, y)

    return pred


def model_house_area(data):
    '''
    单独对房子面积进行建模，特征值为 'house_area'
    '''

    X = data['house_area'].values
    y = data['rent_money'].values
    pred = run(X, y)

    return pred


def model_type_area(conn, data):
    '''
    对房子面积与户型进行建模，特征值为 'room', 'hall', 'toilet', 'house_area'
    '''
    X = data[['room', 'hall', 'toilet', 'house_area']].values
    y = data['rent_money'].values
    pred = run(X, y, conn=conn, insert=False, table='rent')


    return pred


if __name__ == '__main__':
    get_data()
    data = pd.read_csv('data.csv', encoding='utf-8')
    pred_1 = model_house_type(data)
    pred_2 = model_house_area(data)
    pred_3 = model_type_area(conn, data)